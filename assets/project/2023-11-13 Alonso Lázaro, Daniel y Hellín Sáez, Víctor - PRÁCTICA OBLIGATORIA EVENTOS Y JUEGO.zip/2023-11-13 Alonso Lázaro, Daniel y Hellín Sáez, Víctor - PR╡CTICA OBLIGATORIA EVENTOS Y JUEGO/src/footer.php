<?php
    /**
     * @var $src string
     */
    echo <<<HTML
        <footer>
        <a href="https://www.visualdynamics.fun/main/main.php"><img src="$src" alt="Volver"></a>
            <p>&copy; VisualDynamics 2023</p>
        </footer>
        </body>
        </html>
HTML;